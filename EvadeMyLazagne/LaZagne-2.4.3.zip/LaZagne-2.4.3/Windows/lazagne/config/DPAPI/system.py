#!/usr/bin/env python
# -*- coding: utf-8 -*-


from .eater import DataStruct


class CredSystem(DataStruct):
   

    def __init__(self, raw=None):
        self.revision = None
        self.machine = None
        self.user = None
        DataStruct.__init__(self, raw)

    def parse(self, data):
        
        self.revision = data.eat("L")
        self.machine = data.eat("20s")
        self.user = data.eat("20s")
