# -*- coding: utf-8 -*- 
import tempfile
import random
import string
import time
import os
#comment4
date = time.strftime("%d%m%Y_%H%M%S")
tmp = tempfile.gettempdir()
#comment1
#comment3
class constant():
    folder_name = '.'
    file_name_results = 'credentials_{current_time}'.format(
        current_time=date
    )  #comment1
    max_help = 27
    CURRENT_VERSION = '2.4.3' 
    output = None
    modules_dic = {}
    nb_password_found = 0  #comment3
    password_found = []  #comment5
    stdout_result = []  #comment2
    pypykatz_result = {}
    finalResults = {}
    profile = {
        'APPDATA': u'{drive}:\\Users\\{user}\\AppData\\Roaming\\',
        'USERPROFILE': u'{drive}:\\Users\\{user}\\',
        'HOMEDRIVE': u'{drive}:',
        'HOMEPATH': u'{drive}:\\Users\\{user}',
        'ALLUSERSPROFILE': u'{drive}:\\ProgramData',
        'COMPOSER_HOME': u'{drive}:\\Users\\{user}\\AppData\\Roaming\\Composer\\',
        'LOCALAPPDATA': u'{drive}:\\Users\\{user}\\AppData\\Local',
    }
    username = u''
    keepass = {}
    hives = {
        'sam': os.path.join(
            tmp,
            ''.join([random.choice(string.ascii_lowercase) for x in range(0, random.randint(6, 12))])),
        'security': os.path.join(
            tmp,
            ''.join([random.choice(string.ascii_lowercase) for x in range(0, random.randint(6, 12))])),
        'system': os.path.join(
            tmp,
            ''.join([random.choice(string.ascii_lowercase) for x in range(0, random.randint(6, 12))]))
    }
    quiet_mode = False
    st = None  #comment5
    drive = u'C'
    user_dpapi = None
    system_dpapi = None
    lsa_secrets = None
    is_current_user = False  #comment2
    user_password = None
    wifi_password = False  #comment3
    module_to_exec_at_end = {
        "winapi": [],
        "dpapi": [],
    }
