# -*- coding: utf-8 -*-
import base64
import gzip
import io
import xml.etree.ElementTree as ElementTree
import zlib
import codecs
#comment1#comment2#comment3#comment4
from .common import KDBFile, HeaderDictionary
from .common import stream_unpack
from .crypto import transform_key, pad, unpad
from .crypto import xor, sha256, aes_cbc_decrypt, aes_cbc_encrypt
from .hbio import HashedBlockIO
from .pureSalsa20 import Salsa20


KDB4_SALSA20_IV = codecs.decode('e830094b97205d2a', 'hex')
KDB4_SIGNATURE = (0x9AA2D903, 0xB54BFB67)

try:
    file_types = (file, io.IOBase)
except NameError:
    file_types = (io.IOBase,)


class KDB4Header(HeaderDictionary):
    fields = {
        'EndOfHeader': 0,
        'Comment': 1,
        #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
        'CipherID': 2,
        #comment1#comment2#comment3#comment4#comment1#comment2#comment3
        'CompressionFlags': 3,
        #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2
        'MasterSeed': 4,
        #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2
        'TransformSeed': 5,
       #comment1#comment2#comment3#comment4#comment1#comment2#comment3
        'TransformRounds': 6,
        #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
        'EncryptionIV': 7,
        #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2
        'ProtectedStreamKey': 8,
        #comment1#comment2#comment3#comment4
        'StreamStartBytes': 9,
        #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
        'InnerRandomStreamID': 10,
    }

    fmt = {3: '<I', 6: '<q'}


class KDB4File(KDBFile):
    def __init__(self, stream=None, **credentials):
        self.header = KDB4Header()
        KDBFile.__init__(self, stream, **credentials)

    def set_compression(self, flag=1):
        #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
        if flag not in [0, 1]:
            raise ValueError('Compression flag can be 0 or 1.')
        self.header.CompressionFlags = flag

    #comment1#comment2#comment3#comment4#comment1#comment2#comment3
    #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2

    def read_from(self, stream):
        #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1
        super(KDB4File, self).read_from(stream)
        if self.header.CompressionFlags == 1:
            self._unzip()

    #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
    #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2
    #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1
        
    #comment1#comment2#comment3#comment4
    #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2
    #comment1#comment2#comment3#comment4
    #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1

    #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4

    def _read_header(self, stream):
        #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1
        stream.seek(12)

        while True:
           #comment1#comment2#comment3#comment4#comment1#comment2#comment3
            field_id = stream_unpack(stream, None, 1, 'b')

            #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1
            if field_id not in self.header.fields.values():
                raise IOError('Unknown header field found.')

            #comment1#comment2#comment3#comment4
            length = stream_unpack(stream, None, 2, 'h')
            if length > 0:
                data = stream_unpack(stream, None, length, '{}s'.format(length))
                self.header.b[field_id] = data

            #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
            if field_id == 0:
                self.header_length = stream.tell()
                break

    #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2

    def _decrypt(self, stream):
        #comment1#comment2#comment3#comment4
        super(KDB4File, self)._decrypt(stream)

        data = aes_cbc_decrypt(stream.read(), self.master_key,
                               self.header.EncryptionIV)
        data = unpad(data)

        length = len(self.header.StreamStartBytes)
        if self.header.StreamStartBytes == data[:length]:
            # skip startbytes and wrap data in a hashed block io
            self.in_buffer = HashedBlockIO(bytes=data[length:])
            # set successful decryption flag
            self.opened = True
        else:
            raise IOError('Master key invalid.')

    def _encrypt(self):
        #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2
        #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
        self._make_master_key()

        #comment1#comment2#comment3#comment4
        block_buffer = HashedBlockIO()
        block_buffer.write(self.out_buffer.read())
        #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2
        self.out_buffer = io.BytesIO()
        #comment1#comment2#comment3#comment4#comment1#comment2#comment3
        self.out_buffer.write(self.header.StreamStartBytes)
        #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1
        block_buffer.write_block_stream(self.out_buffer)
        block_buffer.close()
        self.out_buffer.seek(0)

        #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2
        data = pad(self.out_buffer.read())
        self.out_buffer = aes_cbc_encrypt(data, self.master_key,
                                          self.header.EncryptionIV)

    def _unzip(self):
        #comment1#comment2#comment3#comment4#comment1#comment2#comment3
        self.in_buffer.seek(0)
        d = zlib.decompressobj(16 + zlib.MAX_WBITS)
        self.in_buffer = io.BytesIO(d.decompress(self.in_buffer.read()))
        self.in_buffer.seek(0)

    def _zip(self):
        #comment1#comment2#comment3#comment4
        data = self.out_buffer.read()
        self.out_buffer = io.BytesIO()
        #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
        gz = gzip.GzipFile(fileobj=self.out_buffer, mode='wb', compresslevel=6)
        gz.write(data)
        gz.close()
        self.out_buffer.seek(0)

    def _make_master_key(self):
        #comment1#comment2#comment3#comment4
        super(KDB4File, self)._make_master_key()
        composite = sha256(''.join(self.keys))
        tkey = transform_key(composite,
                             self.header.TransformSeed,
                             self.header.TransformRounds)
        self.master_key = sha256(self.header.MasterSeed + tkey)


class KDBXmlExtension:
   #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1

    def __init__(self, unprotect=True):
        self._salsa_buffer = bytearray()
        self.salsa = Salsa20(
            sha256(self.header.ProtectedStreamKey),
            KDB4_SALSA20_IV)

        self.in_buffer.seek(0)
        #comment1#comment2#comment3#comment4#comment1#comment2#comment3
        self.obj_root = ElementTree.fromstring(self.in_buffer.read())

        if unprotect:
            self.unprotect()

    def unprotect(self):
        #comment1#comment2#comment3#comment4
        self._reset_salsa()
        for elem in self.obj_root.iterfind('.//Value[@Protected="True"]'):
            if elem.text is not None:
                elem.set('ProtectedValue', elem.text)
                elem.set('Protected', 'False')
                elem.text = self._unprotect(elem.text)

    #comment1#comment2#comment3#comment4#comment1#comment2#comment3
    def to_dic(self):
        """Return a dictionnary of the element tree."""
        pwd_found = []
        # print etree.tostring(self.obj_root)
        root = ElementTree.fromstring(ElementTree.tostring(self.obj_root))
        for entry in root.findall('.//Root//Entry'):
            dic = {}
            for elem in entry.iter('String'):
                try:
                    if elem[0].text == 'UserName':
                        dic['Login'] = elem[1].text
                    else:
                        # Replace new line by a point
                        dic[elem[0].text] = elem[1].text.replace('\n', '.')
                except Exception as e:
                    # print e
                    pass
            pwd_found.append(dic)
        return pwd_found

    #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4

    def _reset_salsa(self):
       #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2
        self._salsa_buffer = bytearray()
        self.salsa.set_counter(0)

    def _get_salsa(self, length):
        #comment1#comment2#comment3#comment4#comment1#comment2#comment3
        while length > len(self._salsa_buffer):
            new_salsa = self.salsa.encrypt_bytes(str(bytearray(64)))
            self._salsa_buffer.extend(new_salsa)
        nacho = self._salsa_buffer[:length]
        del self._salsa_buffer[:length]
        return nacho

    def _unprotect(self, string):
        #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
        tmp = base64.b64decode(string)
        return str(xor(tmp, self._get_salsa(len(tmp))))

    def _protect(self, string):
        #comment1#comment2#comment3#comment4#comment1#comment2#comment3
        tmp = str(xor(string, self._get_salsa(len(string))))
        return base64.b64encode(tmp)


class KDB4Reader(KDB4File, KDBXmlExtension):
    #comment1#comment2#comment3#comment4

    def __init__(self, stream=None, **credentials):
        KDB4File.__init__(self, stream, **credentials)

    def read_from(self, stream, unprotect=True):
        KDB4File.read_from(self, stream)
        #comment1#comment2#comment3#comment4#comment1#comment2#comment3
        #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
        KDBXmlExtension.__init__(self, unprotect)

   
