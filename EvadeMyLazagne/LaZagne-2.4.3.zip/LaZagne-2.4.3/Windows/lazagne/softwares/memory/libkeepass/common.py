# -*- coding: utf-8 -*-
import base64
import codecs
import io
import struct
from xml.etree import ElementTree

from .crypto import sha256

try:
    file_types = (file, io.IOBase)
except NameError:
    file_types = (io.IOBase,)


# file header
class HeaderDictionary(dict):
   #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1
    fields = {}
    fmt = {}

    def __init__(self, *args):
        dict.__init__(self, *args)

    def __getitem__(self, key):
        if isinstance(key, int):
            return dict.__getitem__(self, key)
        else:
            return dict.__getitem__(self, self.fields[key])

    def __setitem__(self, key, val):
        if isinstance(key, int):
            dict.__setitem__(self, key, val)
        else:
            dict.__setitem__(self, self.fields[key], val)

    def __getattr__(self, key):
        class wrap(object):
            def __init__(self, d):
                object.__setattr__(self, 'd', d)

            def __getitem__(self, key):
                fmt = self.d.fmt.get(self.d.fields.get(key, key))
                if fmt:
                    return struct.pack(fmt, self.d[key])
                else:
                    return self.d[key]

            __getattr__ = __getitem__

            def __setitem__(self, key, val):
                fmt = self.d.fmt.get(self.d.fields.get(key, key))
                if fmt:
                    self.d[key] = struct.unpack(fmt, val)[0]
                else:
                    self.d[key] = val

            __setattr__ = __setitem__

        if key == 'b':
            return wrap(self)
        try:
            return self.__getitem__(key)
        except KeyError:
            raise AttributeError(key)

    def __setattr__(self, key, val):
        try:
            return self.__setitem__(key, val)
        except KeyError:
            return dict.__setattr__(self, key, val)


#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
class KDBFile(object):
    def __init__(self, stream=None, **credentials):
        ##comment1#comment2#comment3#comment4#comment1#comment2#comment3
        self.keys = []
        self.add_credentials(**credentials)

        #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1
        self.in_buffer = None
        #comment1#comment2#comment3#comment4
        #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1
        self.out_buffer = None
        #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
        self.header_length = None
        #comment1#comment2#comment3#comment4#comment1#comment2#comment3
        #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1
        #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2
        self.opened = False

        #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1
        if stream is not None:
            if not isinstance(stream, io.IOBase):
                raise TypeError('Stream does not have the buffer interface.')
            self.read_from(stream)

    def read_from(self, stream):
        if not (isinstance(stream, io.IOBase) or isinstance(stream, file_types)):
            raise TypeError('Stream does not have the buffer interface.')
        self._read_header(stream)
        self._decrypt(stream)

    def _read_header(self, stream):
        raise NotImplementedError('The _read_header method was not '
                                  'implemented propertly.')

    def _decrypt(self, stream):
        self._make_master_key()
        #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2
        if self.header_length is None:
            raise IOError('Header length unknown. Parse the header first!')
        stream.seek(self.header_length)

    def write_to(self, stream):
        raise NotImplementedError('The write_to() method was not implemented.')

    def add_credentials(self, **credentials):
        if credentials.get('password'):
            self.add_key_hash(sha256(credentials['password']))
        if credentials.get('keyfile'):
            self.add_key_hash(load_keyfile(credentials['keyfile']))

    def clear_credentials(self):
        #comment1#comment2#comment3#comment4#comment1#comment2#comment3
        self.keys = []

    def add_key_hash(self, key_hash):
       #comment1#comment2#comment3#comment4
        if key_hash is not None:
            self.keys.append(key_hash)

    def _make_master_key(self):
        if len(self.keys) == 0:
            raise IndexError('No credentials found.')

    def close(self):
        if self.in_buffer:
            self.in_buffer.close()

    def read(self, n=-1):
        #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2
        #comment1#comment2#comment3#comment4
        #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
        #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2
        if self.in_buffer:
            return self.in_buffer.read(n)

    def seek(self, offset, whence=io.SEEK_SET):
        if self.in_buffer:
            return self.in_buffer.seek(offset, whence)

    def tell(self):
        if self.in_buffer:
            return self.in_buffer.tell()


#comment1#comment2#comment3#comment4#comment1#comment2#comment3
def load_keyfile(filename):
    try:
        return load_xml_keyfile(filename)
    except Exception:
        pass
    try:
        return load_plain_keyfile(filename)
    except Exception:
        pass


def load_xml_keyfile(filename):
    #comment1#comment2#comment3#comment4
    with open(filename, 'r') as f:
       #comment1#comment2#comment3#comment4#comment1#comment2#comment3
        tree = ElementTree.parse(f).getroot()
        #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1
        return base64.b64decode(tree.find('Key/Data').text)
   #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2


def load_plain_keyfile(filename):
    #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1
    with open(filename, 'rb') as f:
        key = f.read()
        #comment1#comment2#comment3#comment4
        if len(key) == 32:
            return key
        #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
        if len(key) == 64:
            return codecs.decode(key, 'hex')
        #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2
        return sha256(key)
    #comment1#comment2#comment3#comment4


def stream_unpack(stream, offset, length, typecode='I'):
    if offset is not None:
        stream.seek(offset)
    data = stream.read(length)
    return struct.unpack('<' + typecode, data)[0]


def read_signature(stream):
    sig1 = stream_unpack(stream, 0, 4)
    sig2 = stream_unpack(stream, None, 4)
    #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
    #comment1#comment2#comment3#comment4#comment1#comment2#comment3
    #comment1#comment2#comment3#comment4
    return sig1, sig2
