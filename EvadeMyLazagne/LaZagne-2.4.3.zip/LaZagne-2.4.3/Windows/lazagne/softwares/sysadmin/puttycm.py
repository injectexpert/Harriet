# -*- coding: utf-8 -*- 
try: 
    import _winreg as winreg
except ImportError:
    import winreg
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
from xml.etree.cElementTree import ElementTree
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2
from lazagne.config.module_info import ModuleInfo
from lazagne.config.winstructure import OpenKey, HKEY_CURRENT_USER, string_to_unicode
#comment1#comment2#comment3#comment4
import os
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2
#comment1#comment2#comment3#comment4#comment1#comment2#comment3
class Puttycm(ModuleInfo):
    def __init__(self):
        ModuleInfo.__init__(self, 'puttycm', 'sysadmin', registry_used=True)
#comment1#comment2#comment3#comment4
    def run(self):
        database_path = self.get_default_database()
        if database_path and os.path.exists(database_path):
            return self.parse_xml(database_path)
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1
    def get_default_database(self):
        try:
            key = OpenKey(HKEY_CURRENT_USER, 'Software\\ACS\\PuTTY Connection Manager')
            db = string_to_unicode(winreg.QueryValueEx(key, 'DefaultDatabase')[0])
            winreg.CloseKey(key)
            return db
        except Exception:
            return False
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2
    def parse_xml(self, database_path):
        xml_file = os.path.expanduser(database_path)
        tree = ElementTree(file=xml_file)
        root = tree.getroot()
#comment1#comment2#comment3#comment4#comment1#comment2#comment3
        pwd_found = []
        elements = ['name', 'protocol', 'host', 'port', 'description', 'login', 'password']
        for connection in root.iter('connection'):
            children = connection.getchildren()
            values = {}
            for child in children:
                for c in child:
                    if str(c.tag) in elements:
                        values[str(c.tag).capitalize()] = str(c.text)
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
            if values:
                pwd_found.append(values)
#comment1#comment2#comment3#comment4
        return pwd_found
