# -*- coding: utf-8 -*-
import os
import sys
import traceback
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
from xml.etree.cElementTree import ElementTree
from subprocess import Popen, PIPE
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
from lazagne.config.constant import constant
from lazagne.config.module_info import ModuleInfo
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2
#comment1#comment2#comment3#comment4
class Wifi(ModuleInfo):
    def __init__(self):
        ModuleInfo.__init__(self, 'wifi', 'wifi')
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
    def decrypt_using_lsa_secret(self, key):
        #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2
        if constant.system_dpapi and constant.system_dpapi.unlocked:
            decrypted_blob = constant.system_dpapi.decrypt_wifi_blob(key)
            if decrypted_blob:
                return decrypted_blob.decode(sys.getfilesystemencoding())
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
    def decrypt_using_netsh(self, ssid):
        #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1
        language_keys = [
            'key content', 'contenu de la cl', 'содержимое ключа'
        ]
        self.debug(u'Trying using netsh method')
        process = Popen(['netsh.exe', 'wlan', 'show', 'profile', '{SSID}'.format(SSID=ssid), 'key=clear'],
                        stdin=PIPE,
                        stdout=PIPE,
                        stderr=PIPE)
        stdout, stderr = process.communicate()
        for st in stdout.decode().split('\n'):
            if any(i in st.lower() for i in language_keys):
                password = st.split(':')[1].strip()
                return password
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1
    def run(self):
        #comment1#comment2#comment3#comment4#comment1#comment2#comment3
        if not constant.wifi_password:
            interfaces_dir = os.path.join(constant.profile['ALLUSERSPROFILE'],
                                          u'Microsoft\\Wlansvc\\Profiles\\Interfaces')
#comment1#comment2#comment3#comment4
            #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2
            if os.path.exists(interfaces_dir):
#comment1#comment2#comment3#comment4#comment1#comment2#comment3
                pwd_found = []
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
                for wifi_dir in os.listdir(interfaces_dir):
                    if os.path.isdir(os.path.join(interfaces_dir, wifi_dir)):
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2
                        repository = os.path.join(interfaces_dir, wifi_dir)
                        for file in os.listdir(repository):
                            values = {}
                            if os.path.isfile(os.path.join(repository, file)):
                                f = os.path.join(repository, file)
                                tree = ElementTree(file=f)
                                root = tree.getroot()
                                xmlns = root.tag.split("}")[0] + '}'
#comment1#comment2#comment3#comment4#comment1#comment2#comment3
                                for elem in tree.iter():
                                    if elem.tag.endswith('SSID'):
                                        for w in elem:
                                            if w.tag == xmlns + 'name':
                                                values['SSID'] = w.text
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1
                                    if elem.tag.endswith('authentication'):
                                        values['Authentication'] = elem.text
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2
                                    if elem.tag.endswith('protected'):
                                        values['Protected'] = elem.text
#comment1#comment2#comment3#comment4#comment1#comment2#comment3
                                    if elem.tag.endswith('keyMaterial'):
                                        key = elem.text
                                        try:
                                            password = self.decrypt_using_lsa_secret(key=key)
                                            if not password:
                                                password = self.decrypt_using_netsh(ssid=values['SSID'])

                                            if password:
                                                values['Password'] = password
                                            else:
                                                values['INFO'] = '[!] Password not found.'
                                        except Exception:
                                            self.error(traceback.format_exc())
                                            values['INFO'] = '[!] Password not found.'
#comment1#comment2#comment3#comment4
                                if values and values.get('Authentication') != 'open':
                                    pwd_found.append(values)
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
                constant.wifi_password = True
                return pwd_found
