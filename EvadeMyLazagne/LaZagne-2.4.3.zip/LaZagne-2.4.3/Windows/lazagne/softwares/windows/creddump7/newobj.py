#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1
from .object import *
from .types import regtypes as types
from operator import itemgetter
from struct import unpack
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment4
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2
def get_ptr_type(structure, member):
    #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
    if len(member) > 1:
        _, tp = get_obj_offset(types, [structure, member[0]])
        if tp == 'array':
            return types[structure][1][member[0]][1][2][1]
        else:
            return get_ptr_type(tp, member[1:])
    else:
        return types[structure][1][member[0]][1][1]
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
class Obj(object):
    #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1
    def __new__(typ, name, address, space):
        if name in globals():
            # This is a bit of "magic"
            # Could be replaced with a dict mapping type names to types
            return globals()[name](name,address,space)
        elif name in builtin_types:
            return Primitive(name, address, space)
        else:
            obj = object.__new__(typ)
            return obj
    #comment1#comment2#comment3#comment4#comment1#comment2#comment3
    def __init__(self, name, address, space):
        self.name = name
        self.address = address
        self.space = space
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
        self.extra_members = []
    #comment1#comment2#comment3#comment4#comment1#comment2#comment3
    def __getattribute__(self, attr):
        try:
            return object.__getattribute__(self, attr)
        except AttributeError:
            pass
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
        if self.name in builtin_types:
            raise AttributeError("Primitive types have no dynamic attributes")
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2
        try:
            off, tp = get_obj_offset(types, [self.name, attr])
        except Exception:
            raise AttributeError("'%s' has no attribute '%s'" % (self.name, attr))
        #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2
        if tp == 'array':
            a_len = types[self.name][1][attr][1][1]
            l = []
            for i in range(a_len):
                a_off, a_tp = get_obj_offset(types, [self.name, attr, i])
                if a_tp == 'pointer':
                    ptp = get_ptr_type(self.name, [attr, i])
                    l.append(Pointer(a_tp, self.address+a_off, self.space, ptp))
                else:
                    l.append(Obj(a_tp, self.address+a_off, self.space))
            return l
        elif tp == 'pointer':
            #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
            ptp = get_ptr_type(self.name, [attr])
            return Pointer(tp, self.address+off, self.space, ptp)
        else:
            return Obj(tp, self.address+off, self.space)
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1
    def __truediv__(self, other):
        if isinstance(other, (tuple, list)):
            return Pointer(other[0], self.address, self.space, other[1])
        elif isinstance(other, str):
            return Obj(other, self.address, self.space)
        else:
            raise ValueError("Must provide a type name as string for casting")

    def __div__(self, other):
        if isinstance(other, tuple) or isinstance(other, list):
            return Pointer(other[0], self.address, self.space, other[1])
        elif isinstance(other, str):
            return Obj(other, self.address, self.space)
        else:
            raise ValueError("Must provide a type name as string for casting")
    #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1
    def members(self):
       #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1
        membs = [(k, v[0]) for k,v in types[self.name][1].items()]
        membs.sort(key=itemgetter(1))
        return map(itemgetter(0),membs) + self.extra_members
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1
    def values(self):
        #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
        valdict = {}
        for k in self.members():
            valdict[k] = getattr(self, k)
        return valdict
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1
    def bytes(self, length=-1):
        #comment1#comment2#comment3#comment4#comment1#comment2#comment3
        if length == -1:
            length = self.size()
        return self.space.read(self.address, length)

    def size(self):
        #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1
        if self.name in builtin_types:
            return builtin_types[self.name][0]
        else:
            return types[self.name][0]
    #comment1#comment2#comment3#comment4#comment1#comment2#comment3
    def __repr__(self):
        return "<%s @%08x>" % (self.name, self.address)
#comment1#comment2#comment3#comment4
    def __eq__(self, other):
        if not isinstance(other, Obj):
            raise TypeError("Types are incomparable")
        return self.address == other.address and self.name == other.name
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
    def __ne__(self, other):
        return not self.__eq__(other)
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1
    def __hash__(self):
        return hash(self.address) ^ hash(self.name)
#comment1#comment2#comment3#comment4
    def is_valid(self):
        return self.space.is_valid_address(self.address)
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1
    def get_offset(self, member):
        return get_obj_offset(types, [self.name] + member)
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
class Primitive(Obj):
    #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1
    def __new__(typ, *args, **kwargs):
        obj = object.__new__(typ)
        return obj
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
    def __init__(self, name, address, space):
        super(Primitive, self).__init__(name, address, space)
        length, fmt = builtin_types[name]
        data = space.read(address, length)
        if not data:
            self.value = None
        else:
            self.value = unpack(fmt,data)[0]
    
    def __repr__(self):
        return repr(self.value)

    def members(self):
        return []
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1
class Pointer(Obj):
   #comment1#comment2#comment3#comment4#comment1#comment2#comment3
    def __new__(typ, *args, **kwargs):
        obj = object.__new__(typ)
        return obj
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
    def __init__(self, name, address, space, ptr_type):
        super(Pointer, self).__init__(name, address, space)
        ptr_address = read_value(space, name, address)
        if ptr_type[0] == 'pointer':
            self.value = Pointer(ptr_type[0], ptr_address, self.space, ptr_type[1])
        else:
            self.value = Obj(ptr_type[0], ptr_address, self.space)
    #comment1#comment2#comment3#comment4#comment1#comment2#comment3
    def __getattribute__(self, attr):
       #comment1#comment2#comment3#comment4
        try:
            return super(Pointer, self).__getattribute__(attr)
        except AttributeError:
            return getattr(self.value, attr)
    #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
    def __repr__(self):
        return "<pointer to [%s @%08x]>" % (self.value.name, self.value.address)
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1
    def members(self):
        return self.value.members()
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2
class _UNICODE_STRING(Obj):
   #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2
	#comment1#comment2#comment3#comment4#comment1#comment2#comment3
    def __new__(typ, *args, **kwargs):
        obj = object.__new__(typ)
        return obj
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
    def __str__(self):
        return self.Buffer
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1
    #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
    def getBuffer(self):
        return read_unicode_string(self.space, types, [], self.address)
    Buffer = property(fget=getBuffer)
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1
#comment1#comment2#comment3#comment4#comment1#comment2#comment3
class _CM_KEY_NODE(Obj):
    def __new__(typ, *args, **kwargs):
        obj = object.__new__(typ)
        return obj
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
    def getName(self):
        return read_string(self.space, types, ['_CM_KEY_NODE', 'Name'], self.address, self.NameLength.value)
    Name = property(fget=getName)
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2
class _CM_KEY_VALUE(Obj):
    def __new__(typ, *args, **kwargs):
        obj = object.__new__(typ)
        return obj
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
    def getName(self):
        return read_string(self.space, types, ['_CM_KEY_VALUE', 'Name'], self.address, self.NameLength.value)
    Name = property(fget=getName)
#comment1#comment2#comment3#comment4#comment1#comment2#comment3
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2
class _CHILD_LIST(Obj):
    def __new__(typ, *args, **kwargs):
        obj = object.__new__(typ)
        return obj
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1
    def getList(self):
        lst = []
        list_address = read_obj(self.space, types, ['_CHILD_LIST', 'List'], self.address)
        for i in range(self.Count.value):
            lst.append(Pointer("pointer", list_address+(i*4), self.space, ["_CM_KEY_VALUE"]))
        return lst
    List = property(fget=getList)
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
#comment1#comment2#comment3#comment4#comment1#comment2#comment3
class _CM_KEY_INDEX(Obj):
    def __new__(typ, *args, **kwargs):
        obj = object.__new__(typ)
        return obj
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1
    def getList(self):
        lst = []
        for i in range(self.Count.value):
            # we are ignoring the hash value here
            off, tp = get_obj_offset(types, ['_CM_KEY_INDEX', 'List', i*2])
            lst.append(Pointer("pointer", self.address+off, self.space, ["_CM_KEY_NODE"]))
        return lst
    List = property(fget=getList)
